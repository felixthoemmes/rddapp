## Start Server
function(input, output, session) {
  ################
  ## MODEL PAGE ##
  ################
  
  ## Initialize dataframe
  dataframe <- callModule(input_file, "input_file", more_reactive = MORE_REACTIVE)
  
  # Signal UIs when file is ready
  output$df_ready <- reactive(is.data.frame(dataframe()))
  output$df_mi <- reactive({
    req(is.data.frame(dataframe()))
    !is.null(attr(dataframe(), 'mi_id'))
  })
  outputOptions(output, 'df_ready', suspendWhenHidden = F)
  outputOptions(output, 'df_mi', suspendWhenHidden = F)
  
  ## Initialize parameter
  parameter <- callModule(input_parameter, "input_parm", dataframe = dataframe) 

  # Signal UIs when there are two assignments
  output$par_ready <- reactive({req(parameter$assignment1(), parameter$cutoff1(), 
    parameter$treatment(), parameter$outcome()); TRUE})
  outputOptions(output, 'par_ready', suspendWhenHidden = F)
  output$is_frontier <- reactive({req(parameter$assignment2(), parameter$cutoff2()); TRUE})
  outputOptions(output, 'is_frontier', suspendWhenHidden = F)
  output$has_auxiliary <- reactive({length(parameter$auxiliary()) > 0})
  outputOptions(output, 'has_auxiliary', suspendWhenHidden = F)
  
  ## Initialize data summary
  # Show Data Summary, which also determines model type
  model_type <- callModule(data_summary, "data_summary", dataframe = dataframe, 
    parameter = parameter)
  output$model_type <- reactive(model_type()$type)
  outputOptions(output, 'model_type', suspendWhenHidden = F)

  ## Initialize assumption check
  checks <- callModule(assumption_check, "assumption_check", dataframe = dataframe, 
    parameter = parameter)

  ## Initialize model estiamte
  result <- callModule(model_estimate, "model_estimate", dataframe = dataframe, 
    parameter = parameter, model_type = model_type)

  ## Initialize sensitivity analysis
  sensitivities <- callModule(sensitivity_analysis, "sensitivity_analysis", 
    dataframe = dataframe, parameter = parameter, result = result)

  ## Initiatize model report
  # report <- callModule(model_code, 'model_code', dataframe = dataframe, 
  #   parameter = parameter, result = result)

  ################
  ## POWER PAGE ##
  ################
 
  ## Initialized power input
  pw_pars <- callModule(input_power, "input_power") 
  
  ## Simulate power
  # pw_sims <- callModule(simulate_power, 'simulate_power', parameter = pw_pars)
  
}  
## End Server