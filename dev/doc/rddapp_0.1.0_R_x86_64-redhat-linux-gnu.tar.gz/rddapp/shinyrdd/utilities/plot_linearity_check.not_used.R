plot_linearity_check <- function(y, x, cutpoint, binw, span = .75, ...) {
  # x <- x[complete.cases(x)]
  # Grab some summary vars
  x_n <- length(x)
  x_sd <- sd(x, na.rm = T)
  x_min <- min(x, na.rm = T)
  x_max <- max(x, na.rm = T)

  if (cutpoint <= x_min | cutpoint >= x_max) {
    stop("Cutpoint must lie within range of x")
  }
  
  
  l <- floor((x_min - cutpoint)/binw) * binw + binw/2 + cutpoint  #Midpoint of lowest binw
  r <- floor((x_max - cutpoint)/binw) * binw + binw/2 + cutpoint  #Midpoint of highest binw
  lc <- cutpoint - (binw/2)  #Midpoint of binw just left of breakpoint
  rc <- cutpoint + (binw/2)  #Midpoint of binw just right of breakpoint
  j <- floor((x_max - x_min)/binw) + 2
  
  binnum <- round((((floor((x - cutpoint)/binw) * binw + binw/2 + cutpoint) - 
    l)/binw) + 1)
  
  y_bar = tapply(y, binnum, mean, na.rm = T)
  
  
  cellval <- rep(0, j)
  for (i in 1:j) {
    cellval[i] <- y_bar[as.character(i)] 
  }
  
  
  cellmp <- seq(from = 1, to = j, by = 1)
  cellmp <- floor(((l + (cellmp - 1) * binw) - cutpoint)/binw) * binw + binw/2 + cutpoint
  
## PLOTING
 plot(cellval ~ cellmp, xlim = range(x, na.rm = T), 
       ylim = range(cellval, na.rm = T), xlab = NA, ylab = NA,type = "p", pch = 20,...)
  fit_l = loess.smooth(cellmp[cellmp <= cutpoint], cellval[cellmp <= cutpoint], span = span)
  lines(fit_l$x, fit_l$y,
    xlab = NULL, ylab = NULL, lwd = 2)
  fit_r = loess.smooth(cellmp[cellmp > cutpoint], cellval[cellmp > cutpoint], span = span)
  lines(fit_r$x, fit_r$y,
    xlab = NULL, ylab = NULL,lwd = 2)
  abline(v = cutpoint, col = 'red')
} 
