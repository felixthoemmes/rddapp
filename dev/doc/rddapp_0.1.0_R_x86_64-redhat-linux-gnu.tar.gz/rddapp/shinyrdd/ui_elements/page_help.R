navlistPanel(widths = c(3,9),
  "Section A",
  tabPanel("Topic 1", 
    helpText("I help you on Topic 1.")),
  tabPanel("Topic 2",
    helpText("I help you on Topic 2.")),
  "Section B",
  tabPanel("Topic 3",
    helpText("I help you on Topic 3."))
)