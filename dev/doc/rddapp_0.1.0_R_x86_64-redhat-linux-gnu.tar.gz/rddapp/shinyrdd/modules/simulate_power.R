# Module UI
simulate_powerUI = function(id){
  ns = NS(id)
  tagList(
    p(),
    div(class='panel panel-default',
      div(class='panel-heading',
        h6('Table 5.1',strong('Powers of RDD Estimates'), class='pull-left'),
        actionButton(ns('power_simulate'), label = NULL, icon = icon('refresh'), class='pull-right'),
        div(class='clearfix')
      ),
      div(class='panel-body',
        fluidRow(
          column(9,
            DT::dataTableOutput(ns('power_table')),
            uiOutput(ns('power_table_note'))
          ),
          column(3,
            h6(class='badge','Sample Size'),
            numericInput(ns('power_n'), label = NULL, min = 1, value = 100),
            h6(class='badge','Iterations'),
            numericInput(ns('power_samples'), label = NULL, min = 1, value = 500)
          )
        )
      )
    ),
    
    div(class='panel panel-default',
      div(class='panel-heading',
        h6('Figure 5.1',strong('Powers across Sample Sizes'), class='pull-left'),
        div(class='btn-toolbar  pull-right',
          div(class='btn-group',
            actionButton(ns('power_chart_simulate'), label = NULL, icon=icon('refresh')),
            actionButton(ns('power_chart_halt'), label = NULL, icon = icon('stop'))
          ),
          downloadButton(ns('power_chart_pdf'), label = NULL, 
            title = 'Save Plot as PDF', class='pull-right')
          
        ),
        div(class='clearfix')
      ),
      div(class='panel-body',
        fluidRow(
          column(9, plotOutput(ns('power_chart'), height = '520px')),
          column(3, 
            h6(class='badge','Minimum Sample Size'),
            numericInput(ns('power_chart_n_min'), label = NULL, min = 1, value  = 50),
            h6(class='badge','Maximum Sample Size'),
            numericInput(ns('power_chart_n_max'), label = NULL, min = 1, value  = 500),
            h6(class='badge','Number of Steps'),
            numericInput(ns('power_chart_n_step'), label = NULL, min = 1, value  = 5),
            h6(class='badge','Iterations in Each Step'),
            numericInput(ns('power_chart_iter'), label = NULL, min = 1, value = 500),
            
            hr(),
            h6(class='badge','Group Lines by'),
            selectizeInput(ns('power_chart_by'), label = NULL, 
              choices = c('Model Type' = 'type', 'Alpha Level' = 'alpha')),
            conditionalPanel(condition = sprintf("input['%s'] == 'alpha'", ns('power_chart_by')) ,
              h6(class='badge','Show Model Type'),
              selectizeInput(ns('power_chart_type'), label = NULL, selected = 'Linear',
                choices = c('Linear','Optimal' = 'Opt'))
            ),
            conditionalPanel(condition = sprintf("input['%s'] == 'type'", ns('power_chart_by')) ,
              h6(class='badge','Show Alpha Level'),
              selectizeInput(ns('power_chart_alpha'), label = NULL, 
                choices = c('.05' = 'a3', '.01' = 'a2', '.001' = 'a1' ))
            )
          )
        )
      )
      
      
    )
    
  )
  
  
}


# Module Server

simulate_power = function(input, output, session, parameter){
  
  ## SINGLE RUN SIMULATION
  counter = reactiveValues(val = 0)
  
  result = reactiveValues(summary = NULL,summaries = list())
  
  observeEvent(parameter(), {
    result$summary = matrix('-', nrow = 2, ncol = 6)
    result$summaries = list()
    counter$val = 0
  })
  
  observeEvent(input$power_simulate, {
    req(parameter())
    str(parameter())
    res = withProgress(message = 'Simulating...', value = NULL, 
      expr = power_analy(
        num.rep = input$power_samples, 
        sample.size = input$power_n, 
        x.dist = parameter()$x_dist,
        x.para = parameter()$x_para, cut = parameter()$x_c,
        fuzzy.prob = parameter()$x_p,coeff = parameter()$m_coef, 
        eta.sq = parameter()$m_eta2
      ))
    # restructure for display
    result$summary = res
  })
  
  output$power_table = DT::renderDataTable(server = F, 
    expr = {
      req(is.matrix(result$summary))
      # CREATE A MULTI COLUMN TABLE HEAD
      header = tags$table(class = 'display',
        tags$thead(
          tags$tr(
            tags$th(rowspan = 2,  ''),
            tags$th(rowspan = 2,  'S'),
            tags$th(colspan = 2, 'Treatment Effects', style = 'text-align: center'),
            tags$th(rowspan = 2,  ''),
            tags$th(colspan = 3, 'Power', tags$sup('a'), style = 'text-align: center')
          ),
          tags$tr(
            lapply(c('Mean', 'Variance', '.001', '.01','.05'),
              tags$th, style = 'text-align:right')
          )
        )
      )
      
      dt = DT::datatable(
        data = {
          mat = cbind(result$summary[,1:3], NA, result$summary[,4:6])
          rbind(NA, mat[1,], NA, mat[2,])
        },
        options = list(
          responsive = T,
          pageLength = 8,
          scrollX = TRUE,
          searching = FALSE,
          ordering = FALSE,
          dom = 't',
          autoWidth = F,
          columnDefs = list(list(className = 'dt-right', targets = 1:7))
        ),
        rownames = c('Parametric',
          '- Linear',# '- Quadratic','- Cubic',
          'Nonparametric',
          '- Optimal'#, '- Half','- Double'
        ),
        selection = 'none',
        container = header
      )
      DT::formatRound(dt, columns = 2:7, 3)
      # dt = DT::formatPercentage(dt, columns = 5:7, 2)
    })
  
  output$power_table_note = renderUI({
    req(result$summary)
    
    h6(em('Note.'), 
      'S = successful simulations.', 
      tags$sup('a'), '1 - Type II error rates across successful simulations, given a confidence level.')
  })
  
  ## POWER CHART
  power_chart = function(df){
    plot.new()
    plot.window(ylim = 0:1, xlim=c(input$power_chart_n_min, input$power_chart_n_max))
    box()
    axis(1); mtext('Sample Size', 1, 2)
    axis(2); mtext('Power', 2, 2)
    grid(lty = 3, col = 'black')
    
    if(nrow(df) > 0){
      if(input$power_chart_by == 'alpha'){
        points(a3 ~ n, subset(df, type == input$power_chart_type), type = 'b', col = 'black', pch = 0, lwd = 2)
        points(a2 ~ n, subset(df, type == input$power_chart_type), type = 'b', col = 'red4', pch = 1, lwd = 2)
        points(a1 ~ n, subset(df, type == input$power_chart_type), type = 'b', col = 'blue4', pch = 2, lwd = 2)
        legend(x = 'bottomright', 
          legend = c(expression(alpha == .001), expression(alpha == .01), expression(alpha == .05)),
          pch = 0:2,
          col = c('black','red4','blue4'),
          bty = 'n'
        )
      } else {
        fml = as.formula(sprintf('%s ~ n', input$power_chart_alpha)) 
        
        points(fml, data = subset(df, type == 'Linear'), type = 'b', col = 'red4', pch = 1, lwd = 2)
        # points(fml, data = subset(df, type == 'Quadratic'), type = 'b', col = 'red4', pch = 16, lwd = 2)
        # points(fml, data = subset(df, type == 'Cubic'), type = 'b', col = 'navy', pch = 17, lwd = 2)
        points(fml, data = subset(df, type == 'Opt'), type = 'b', col = 'blue4', pch = 2 , lwd = 2)
        # points(fml, data = subset(df, type == 'Half.Opt'), type = 'b', col = 'red', pch = 1, lty = 2, lwd = 2)
        # points(fml, data = subset(df, type == 'Double.Opt'), type = 'b', col = 'blue', pch = 2, lty = 2, lwd = 2)
        legend(x = 'bottomright', 
          legend = c('Linear','Optimal'),
          pch = 1:2,
          col = c('red4','blue4'),
          # ncol = 2,
          bty = 'n'
        )
      }
    }
  }
  output$power_chart = renderPlot(bg = 'transparent', expr = {
    
    par(mar=c(3,3,0.5,0))
    rect(par("usr")[1],par("usr")[3],par("usr")[2],par("usr")[4],col = "white")
    par(new = T)
    
    power_chart(do.call(rbind.data.frame, result$summaries))
    
  })
  
  N = reactive({seq(input$power_chart_n_min, input$power_chart_n_max,length.out =  input$power_chart_n_step)})
  
  observeEvent(input$power_chart_simulate, {
    result$summaries = list()
    counter$val = 1
  })
  
  observeEvent(input$power_chart_halt, {
    result$summaries = list()
    counter$val = 0
  })
  
  observe({
    input$power_chart_simulate
    if(isolate(counter$val <= length(N()) & counter$val > 0)) {
      isolate({
        n = N()[counter$val]
        print(n)
        res = as.data.frame(
          withProgress(message = 'Simulating...', value = NULL, detail = sprintf('N = %g', n),
            expr = power_analy(
              num.rep = input$power_chart_iter,
              sample.size = n, 
              x.dist = parameter()$x_dist,
              x.para = parameter()$x_para, 
              cut = parameter()$x_c,
              fuzzy.prob = parameter()$x_p,
              coeff = parameter()$m_coef,
              eta.sq = parameter()$m_eta2
            )))
        result$summaries[[counter$val]] = setNames(cbind(rownames(res), res, n = n),
          c('type','s','m','v','a1','a2','a3','n'))
        
        counter$val = counter$val + 1
      })
      
      invalidateLater(0, session)
    } 
  })
  
  output$power_chart_pdf = downloadHandler(
    filename = 'power_chart.pdf',
    content = function(file) {
      pdf(file)
      power_chart(do.call(rbind.data.frame, result$summaries))
      dev.off()
    }
  )
}