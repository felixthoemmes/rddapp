# rddapp 0.1.0

- Initial commit.

- Add R functions: estimation, power analysis, and assumption checks.

- Add R tests: estimation and assumption checks.

- Add CARE dataset.