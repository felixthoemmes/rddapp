# Module UI
model_codeUI = function(id){
  ns = NS(id)
  tagList(
    p(),
    wellPanel(
      helpText('Codes...')
    )
  )
}


# Module Server

model_code = function(input, output, session, dataframe, parameter, result){

}