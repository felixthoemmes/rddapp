plot_sens_bw = function(object, steps = 20, level = .95,  cached_summaries = NULL, plot = T, bw_range = NULL){
  
  if(!class(object) %in% c('rd','mrd')) stop('rd is not a RD or MRD object.')
  
  d <- as.data.frame(object$frame)
  
  if (length(object$na.action) > 0) 
    d <- d[-object$na.action, ]
  
  if ("kernel" %in% names(object$call)) 
    kern <- eval.parent(object$call$kernel) else kern <- "triangular"
  
  if (class(object) == 'mrd') {
    if('method' %in% names(object$call))
       object$call$method = setdiff(object$call$method, 'front') else object$call$method = c('center','univ')
  }
   
  
  if(is.null(bw_range)){
    if(class(object)=='rd') {
      bw_range = c(object$bw[4], object$bw[4]) * c(1/3, 3)
      bws = c(seq(bw_range[1], bw_range[2], length.out = steps-1))
    }  else  {
      bw_range = range(object$center$tau_MRD$bw[4], object$univ$tau_R$bw[4], object$univ$tau_M$bw[4]) * c(1/3, 3)
      bws = unique(c(seq(bw_range[1], bw_range[2], length.out = steps-1), 
        object$center$tau_MRD$bw[4], object$univ$tau_R$bw[4], object$univ$tau_M$bw[4],
        object$center$tau_MRD$bw[5], object$univ$tau_R$bw[5], object$univ$tau_M$bw[5],
        object$center$tau_MRD$bw[6], object$univ$tau_R$bw[6], object$univ$tau_M$bw[6]))
    }
  }
  
  bws = bws[bws >= bw_range[1] & bws <= bw_range[2]]
  
  # SIMULATE FUNCTIONS
  redo_rd_varying_bw = function(bw, rd) {
    # rd$call$cutpoint <- cut 
    rd$call$bw = bw
    try({
      m = eval.parent(rd$call, n = 3)
      opt_idx = which(names(m$est) == 'Usr')[1]
      list(est = m$est[opt_idx], se = m$se[opt_idx], 
        bw = bw)
    })
  }
  
  redo_mrd_varying_bw = function(bw, mrd) {
    # mrd$call$cutpoint <- cut 
    mrd$call$bw = bw
    
    try({
      m = eval.parent(mrd$call)
      rbind.data.frame(
        list(est = m$center$tau_MRD$est['Usr'], se = m$center$tau_MRD$se['Usr'], bw = bw, type = 'center'),
        list(est = m$univ$tau_R$est['Usr'], se = m$univ$tau_R$se['Usr'], bw = bw, type = 'univ1'),
        list(est = m$univ$tau_M$est['Usr'], se = m$univ$tau_M$se['Usr'], bw = bw, type = 'univ2')
      )
    })
  }
  
  
  # SIMULATING
  need_simulation = F
  if(is.null(cached_summaries)) {
    need_simulation = T
  } else {
    if (min(cached_summaries$summaries$bw) > bw_range[1] | 
        max(cached_summaries$summaries$bw) < bw_range[2] |
        cached_summaries$steps != steps)
      need_simulation = T
  }
  
  
  if(need_simulation) {
    if(class(object)=='rd'){
      results = lapply(bws, redo_rd_varying_bw, rd = object)
      summaries = 
        do.call(rbind.data.frame, 
          results[sapply(results, class) == 'list'])
    } else {
      results = lapply(bws, redo_mrd_varying_bw, mrd = object)
      summaries = do.call(rbind.data.frame, results)
    }

    print('simulated.')
  } else {
    summaries = cached_summaries$summaries
  }
  
  summaries = within(summaries,{
    lwr =  est + qnorm((1-level)/2) * se
    upr =  est + qnorm((1-level)/2, lower.tail = F) * se
  })
  
  if(class(object)=='mrd'){
    summaries_full = within(merge(data.frame(bw = bws), 
      summaries, by = 'bw', all.x = T),{
        col = ifelse(bw %in% object$center$tau_MRD$bw[4:6], "red", 'black')
        col = ifelse(bw %in% object$univ$tau_R$bw[4:6], "red", 'black')
        col = ifelse(bw %in% object$univ$tau_M$bw[4:6], "red", 'black')
        col = ifelse(bw == object$center$tau_MRD$bw[5] & type == 'center','blue',col)
        col = ifelse(bw == object$univ$tau_R$bw[5] & type == 'univ1','blue',col)
        col = ifelse(bw == object$univ$tau_M$bw[5] & type == 'univ2','blue',col)
        col = ifelse(bw == object$center$tau_MRD$bw[6] & type == 'center','green',col)
        col = ifelse(bw == object$univ$tau_R$bw[6] & type == 'univ1','green',col)
        col = ifelse(bw == object$univ$tau_M$bw[6] & type == 'univ2','green',col)
        # pch = ifelse(bw %in% object$bw[4:6], 19, 1)
        # pch = ifelse(bw %in% object$bw[4:6], 19, 1)
        # pch = ifelse(bw == object$bw[5],15,pch)
        # pch = ifelse(bw == object$bw[6],17,pch)
        # pch = ifelse(is.na(est),4,pch)
      })
  } else {
    summaries_full = within(merge(data.frame(bw = bws), 
      summaries, by = 'bw', all.x = T),{
        col = ifelse(bw %in% object$bw[4:6], "red4", 'black')
        col = ifelse(bw == object$bw[5],'blue4',col)
        col = ifelse(bw == object$bw[6],'green4',col)
        # pch = ifelse(bw %in% object$bw[4:6], 19, 1)
        # pch = ifelse(bw == object$bw[5],15,pch)
        # pch = ifelse(bw == object$bw[6],17,pch)
        # pch = ifelse(is.na(est),4,pch)
      })
  }
  
  
  if(class(object)=='rd'){
    poly_coord =rbind(setNames(summaries_full[order(summaries_full), 
      c('bw','lwr')], c('bw','ci')),
      setNames(summaries_full[order(summaries_full$bw,decreasing = T), 
        c('bw','upr')],c('bw','ci')))
    
  } else {
    poly_coord = 
      by(summaries_full, summaries_full$type, function(df){
        rbind(setNames(df[order(df$bw), 
          c('bw','lwr')], c('bw','ci')),
          setNames(df[order(df$bw,decreasing = T), 
            c('bw','upr')],c('bw','ci')))
      })
  }

  
  # START PLOTING
  if(plot){
    plot.new()
    yrange = range(c(summaries_full[c('est')],0, summaries_full[c('upr','lwr')]), na.rm = T)
    plot.window(xlim = bw_range, 
      ylim = yrange + c(0, .25*(yrange[2] - yrange[1])))
    box();axis(1);axis(2)
    # CI areas
    
    if(class(object)=='rd'){
      
      polygon(poly_coord$bw[!is.na(poly_coord$ci)], 
        poly_coord$ci[!is.na(poly_coord$ci)],
        col = adjustcolor('black', alpha.f = .1), border = NA)
    } else {
      polygon(poly_coord$center$bw[!is.na(poly_coord$center$ci)], 
        poly_coord$center$ci[!is.na(poly_coord$center$ci)],
        col = adjustcolor('red', alpha.f = .1), border = NA)
      
      polygon(poly_coord$univ1$bw[!is.na(poly_coord$univ1$ci)], 
        poly_coord$univ1$ci[!is.na(poly_coord$univ1$ci)],
        col = adjustcolor('blue', alpha.f = .1), border = NA)
            
      polygon(poly_coord$univ2$bw[!is.na(poly_coord$univ2$ci)], 
        poly_coord$univ2$ci[!is.na(poly_coord$univ2$ci)],
        col = adjustcolor('green', alpha.f = .1), border = NA)
    }
      
    # abline(h = 0)
    abline(h = 0, lty =2)
    # abline(v = bw, lty=2)
    
    
    # Estimates 
    
    if(class(object)=='rd'){
      points(est ~ bw, data= summaries_full, 
        col = col,
        type = 'b', lwd = 2)
    } else {
      points(est ~ bw, data= subset(summaries_full, type =='center'), 
        col = 'red', pch = 1,
        type = 'b', lwd = 2)
      points(est ~ bw, data= subset(summaries_full, type =='univ1'), 
        col = 'blue', pch = 2,
        type = 'b', lwd = 2)
      points(est ~ bw, data= subset(summaries_full, type =='univ2'), 
        col = 'green', pch = 3,
        type = 'b', lwd = 2)
    }

    # 
    # points(!is.na(est) ~ bw, 
    #   subset(summaries_full, is.na(est)),
    #   pch = 4, col = 'black')
    
    
    # if (any(c(19,15,17,4) %in% summaries_full$pch))
      # legend('topright', bg = 'white',bty = 'n',
      #   legend = c('optimal','half','double','failed estimation')[c(19,15,17,4) %in% summaries_full$pch],
      #   pch = c(19,15,17,4)[c(19,15,17,4) %in% summaries_full$pch],
      #   col = c('red4','blue4','green4','black')[c(19,15,17,4) %in% summaries_full$pch]
      # )
    
  }
  
  return(list(summaries = summaries, 
    steps=steps))
}
