fluidRow(
  # Sidebar ()
  column(width = 5,
    input_powerUI('input_power')
  ),
  
  # Main Panel
  column(width = 7,
    tabsetPanel(
      tabPanel("Monte Carlo Simulation", icon = icon('random'), 
        simulate_powerUI('simulate_power')
      ),
      
      tabPanel("R Code", icon = icon('code'),
        helpText('I show reproducable R codes for power analysis.'),
        verbatimTextOutput("power_code"))
    )
  )
)