#' Cutoff Sensitivity Simulation for  \code{rd} object.
#'
#' \code{sens_cutoff.rd} refit the supplemented model 
#' with varying cutoff(s). Other estimation parameters, such as the automatically 
#' calculated bandwidth, are hold constantly.
#' 
#' @param object a object returned by \code{rd_est()} or \code{rd_impute()}.
#' @param cutoffs a numeric vector of cutoff values to be used in the refitting 
#' of a \code{rd} object.  
#'
#' @return a dataframe contains the estimate \code{est} and standard error \code{se} 
#' for each cutoff values.
#'
#' @export
#'
#' @author Liao Wang
#'
#' @examples
#' x <- runif(1000, -1, 1)
#' cov <- rnorm(1000)
#' y <- 3 + 2 * x + 3 * cov + 10 * (x >= 0) + rnorm(1000)
#' m <- rd_est(y ~ x | cov)
#' sim_results <- rd_sens_cutoff(m, seq(-.5,.5, length.out = 10))

rd_sens_cutoff <- function(object, cutoffs) {
  if(class(object)!='rd') stop('object is not a rd object.')
  
  sim_results = lapply(cutoffs, function(cutoff) {
    object$call$cutpoint = cutoff
    object$call$est.cov = F
    object$call$bw = object$bw['Opt']
    new_model = eval.parent(object$call, 3)
     
    return(
      data.frame(
        est = new_model$est, 
        se = new_model$se, 
        A1 = cutoff, 
        model = c('linear','quadratic','cubic','optimal','half','double'), 
        stringsAsFactors = F, row.names = 1:6)
    )
  })
  
  return(
    do.call(rbind.data.frame, sim_results)
  )
}

