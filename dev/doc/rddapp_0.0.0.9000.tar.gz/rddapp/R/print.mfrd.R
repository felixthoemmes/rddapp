#' Print the Multivariate Frontier Regression Discontinuity
#' 
#' \code{print.mfrd} is based on \code{print.RD} the \pkg{rdd} package. 
#' It prints a very basic summary of the multivariate frontier regression discontinuity
#' 
#' @method print mfrd
#' @param x \code{mfrd} object, typically the result of \code{\link{mfrd_est}}
#' @param digits number of digits to print
#' @param ... unused
#' @include mfrd_est.R
#' @export
#' @author Ze Jin <\email{zj58@@cornell.edu}>

print.mfrd <- function(x, digits = max(3, getOption("digits") - 3), ...) {
  cat("\nCall:\n", paste(deparse(x$call), sep = "\n", collapse = "\n"), "\n\n", 
    sep = "")
  
  cat("Coefficients:\n")
  print.default(format(x$est, digits = digits), print.gap = 2, quote = FALSE)
  cat("\n")
  invisible(x)
} 
