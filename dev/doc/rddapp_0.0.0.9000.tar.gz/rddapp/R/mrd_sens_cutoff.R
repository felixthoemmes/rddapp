#' Cutoff Sensitivity Simulation for \code{mrd} object.
#'
#' \code{mrd_sens_cutoff} refit the supplemented model 
#' with varying cutoff(s). Other estimation parameters, such as the automatically 
#' calculated bandwidth, are hold constantly.
#' 
#' @param object a object returned by #' \code{mrd_est()} or \code{mrd_impute()}. 
#' @param cutoffs a two-column numeric matrix of paired cutoff values 
#' to be used for refitting a \code{mrd} object.  
#'
#' @return a dataframe contains the estimate \code{est} and standard error \code{se} 
#' for each pairs of cutoffs
#'
#' @export
#'
#' @author Liao Wang
#'
#' @examples
#' x1 <- runif(1000, -1, 1)
#' x2 <- rnorm(1000, 10, 2)
#' cov <- rnorm(1000)
#' y <- 3 + 2 * x1 + 1 * x2 + 3 * cov + 10 * (x1 >= 0) + 5 * (x2 >= 10) + rnorm(1000)
#' m <- mrd_est(y ~ x1 + x2 | cov, cutpoint = c(0,10))
#' sim_results <- mrd_sens_cutoff(m, expand.grid(A1 = seq(-.5,.5, length.out = 5), A2 = 10))

mrd_sens_cutoff <- function(object, cutoffs) {
  if(class(object)!='mrd') stop('object is not a mrd object.')
  
  sim_results = apply(cutoffs, 1, function(cutoff) {
    if(is.null(object$center) & is.null(object$univ)) stop('mrd object was not estimated uing the centering or univariate method')
    object$call$cutpoint = cutoff
    object$call$est.cov = F
    
    result_center = if(!is.null(object$center)) {
      object$call$bw = object$center$tau_MRD$bw['Opt']
      object$call$method = 'center'
      new_model =eval.parent(object$call, 3)
      data.frame(
        est = new_model$center$tau_MRD$est, 
        se = new_model$center$tau_MRD$se, 
        A1 = cutoff[1], 
        A2 = cutoff[2], 
        model = paste('center',c('linear','quadratic','cubic','optimal','half','double'),sep='-'), 
        stringsAsFactors = F, row.names = 1:6)
    } 
    result_univ = if (!is.null(object$univ)) {
      object$call$bw = object$univ$tau_R$bw['Opt']
      object$call$method = 'univ'
      new_model = eval.parent(object$call, 3)
      result_univ = rbind(
        data.frame(
          est = new_model$univ$tau_R$est, 
          se = new_model$univ$tau_R$se, 
          A1 = cutoff[1], 
          A2 = cutoff[2], 
          model = paste('univ1',c('linear','quadratic','cubic','optimal','half','double'),sep='-'), 
          stringsAsFactors = F, row.names = 1:6),
        data.frame(
          est = new_model$univ$tau_M$est, 
          se = new_model$univ$tau_M$se, 
          A1 = cutoff[1], 
          A2 = cutoff[2], 
          model = paste('univ2',c('linear','quadratic','cubic','optimal','half','double'),sep='-'), 
          stringsAsFactors = F, row.names = 1:6)
      )
    }
    return(
      rbind(result_center, result_univ)
    )
  })
  return(do.call(rbind.data.frame, sim_results))
}