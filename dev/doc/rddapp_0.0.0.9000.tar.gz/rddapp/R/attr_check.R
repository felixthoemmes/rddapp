#' Attrition checks
#'
#' Reports missing data on treatment variable, assignment variable, and outcome
#' Currently only supporting the design with one assignment variable
#' 
#' @param x1 A numeric object, the assignment variable.
#' @param y A numeric object, the outcome variable, with the same dimensionality as \code{x}.
#' @param t A numeric object, the treatment variable,  with the same dimensionality as \code{x} and \code{y}.
#' @param x2 A numeric object, the secondary assignment variable.
#' 
#' @return A list with the missing data numbers and percentages for all variables and subgroups by treatment.
#' 
#' @author Felix Thoemmes
#' 
#' @note Attrition checks

attr_check <- function(x1, y, t, x2 = NULL) {
  res = list(overallt = length(t), #get length of vector t to determine number of cases
    
    overallt0 = sum(t == 0, na.rm = TRUE),#how many non-missing units coded 0 
    overallt1 = sum(t == 1, na.rm = TRUE),#how many non-missung units coded 1 
    
    overallmisst = sum(is.na(t)),#how many missing units in t  
    overallmissy = sum(is.na(y)),#how many missung units in y  
    overallmissyt0 = sum(is.na(y[t == 0 & !is.na(t)])),#how many missing units in y when t=0
    overallmissyt1 = sum(is.na(y[t == 1 & !is.na(t)])),#how many missing units in y when t=1
    overallmissx1 = sum(is.na(x1)),#how many missung units in x1  
    overallmissx1t0 = sum(is.na(x1[t == 0 & !is.na(t)])),#how many missing units in x1 when t=0
    overallmissx1t1 = sum(is.na(x1[t == 1 & !is.na(t)]))) #how many missing units in x1 when t=1
  
  #if there is a second assignment x2, run the following
  if (is.null(x2)) 
    return(res)
  else
    return(c(res, 
      list(
        overallmissx2 = sum(is.na(x2)),#how many missung units in x2 
        overallmissx2t0 = sum(is.na(x2[t == 0 & !is.na(t)])),#how many missing units in x2 when t=0
        overallmissx2t1 = sum(is.na(x2[t == 1 & !is.na(t)]))
      ) #how many missing units in x2 when t=1
    ))
}
