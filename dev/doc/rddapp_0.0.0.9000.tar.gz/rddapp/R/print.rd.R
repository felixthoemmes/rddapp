#' Print the Regression Discontinuity
#' 
#' \code{print.rd} is based on \code{print.RD} the \pkg{rdd} package. It prints a very basic summary of the regression discontinuity
#' 
#' @method print rd
#' @param x \code{rd} object, typically the result of \code{\link{rd_est}}
#' @param digits number of digits to print
#' @param ... unused
#' @include rd_est.R
#' @export
#' @author Drew Dimmery <\email{drewd@@nyu.edu}>

print.rd <- function(x, digits = max(3, getOption("digits") - 3), ...) {
  cat("\nCall:\n", paste(deparse(x$call), sep = "\n", collapse = "\n"), "\n\n", 
    sep = "")
  
  cat("Coefficients:\n")
  print.default(format(x$est, digits = digits), print.gap = 2, quote = FALSE)
  cat("\n")
  invisible(x)
} 
