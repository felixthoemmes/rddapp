#' rddapp: A package for regression discontinuity design.
#'
#' The rddapp package provides three categories of important functions:
#' estimation, power analysis and assumption check.
#' 
#' @section Estimation:
#' parametric, parametric fuzzy, parametric frontier,
#' non-parametric, non-parametric fuzzy, non-parametric frontier.
#'
#' @section Power analysis:
#' parametric, parametric fuzzy, parametric frontier,
#' non-parametric, non-parametric fuzzy, non-parametric frontier.
#'
#' @name rddapp-package
#' @aliases rddapp
#' @docType package
#' @title Regression Discontinuity Design Package
#' @author Ze Jin \email{zj58@@cornell.edu}, 
#' Liao Wang \email{wl483@cornell.edu},
#' Felix Thoemmes, \email{fjt36@cornell.edu}
NULL 
