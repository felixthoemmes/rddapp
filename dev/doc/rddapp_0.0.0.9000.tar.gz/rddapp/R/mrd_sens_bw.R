#' Bandwidth Sensitivity Simulation for \code{mrd} object.
#'
#' \code{sens_cutoff.mrd} refit the supplemented model 
#' with varying bandwidth. Other estimation parameters are hold constantly.
#'
#' @param object a object returned by \code{mrd_est()} or \code{mrd_impute()}. 
#' @param approach a string of the approach/estimate to be refitted, 
#' choosing from \code{c("center","univ1","univ2")}
#' @param bws a positive numeric vector of bandwidth for refitting a \code{mrd} object.  
#'
#' @return a dataframe contains the estimate \code{est} and standard error \code{se} 
#' for each supplemented bandwidth.
#' 
#' @export
#'
#' @author Liao Wang
#'
#' @examples
#' x1 <- runif(1000, -1, 1)
#' x2 <- rnorm(1000, 10, 2)
#' cov <- rnorm(1000)
#' y <- 3 + 2 * x1 + 1 * x2 + 3 * cov + 10 * (x1 >= 0) + 5 * (x2 >= 10) + rnorm(1000)
#' m <- mrd_est(y ~ x1 + x2 | cov, cutpoint = c(0,10))
#' sim_results <- mrd_sens_bw(m, approach = 'univ1', bws = seq(0.1,1, length.out = 5))

mrd_sens_bw <- function(object, approach = c('center','univ1','univ2'), bws) {
  if(class(object)!='mrd') stop('object is not a mrd object.')
  if(any(bws <=0)) stop('bandwidth must be positive')
  if(!approach %in%  c('center','univ1','univ2')) stop('unknow approach.')
  if(approach == 'center' & is.null(object$center)) stop('mrd object was not estimated uing the centering approach')
  if(approach %in% c('univ1','univ2') & is.null(object$univ)) stop('mrd object was not estimated uing the univariate approach')
  
   sim_results = lapply(bws, function(bw) {
    
    
    object$call$bw = bw
    object$call$est.cov = F
    object$call$method = switch(approach, center = 'center', 'univ')
    new_model =eval.parent(object$call, 3)
    switch(approach,
      center = data.frame(
        est = new_model$center$tau_MRD$est['Usr'], 
        se = new_model$center$tau_MRD$se[4], # Wang used index here because the returned array's names are constant 'Z' or 'Tr' 
        bw = bw,
        model = paste('center-usr'), 
        stringsAsFactors = F),
      univ1 = data.frame(
        est = new_model$univ$tau_R$est['Usr'], 
        se = new_model$univ$tau_R$se[4], 
        bw = bw,
        model = paste('univ1-usr'), 
        stringsAsFactors = F),
      univ2 = data.frame(
        est = new_model$univ$tau_M$est['Usr'], 
        se = new_model$univ$tau_M$se[4], 
        bw = bw,
        model = paste('univ2-usr'), 
        stringsAsFactors = F)
      )
  })
   
  return(do.call(rbind.data.frame, sim_results))
}