#' Bandwidth Sensitivity Simulation for \code{rd} object.
#'
#' \code{sens_cutoff.rd} refit the supplemented model 
#' with varying bandwidth. Other estimation parameters are hold constantly.
#' 
#' @param object a object returned by \code{rd_est()} or \code{rd_impute()}. 
#' @param bws a positive numeric vector of bandwidth for refitting a \code{rd} object.  
#'
#' @return a dataframe contains the estimate \code{est} and standard error \code{se} 
#' for each supplemented bandwidth.
#'
#' @export
#'
#' @author Liao Wang
#'
#' @examples
#' x <- runif(1000, -1, 1)
#' cov <- rnorm(1000)
#' y <- 3 + 2 * x + 3 * cov + 10 * (x >= 0) + rnorm(1000)
#' m <- rd_est(y ~ x | cov)
#' sim_results <- rd_sens_bw(m,  bws = seq(0.1,1, length.out = 5))

rd_sens_bw <- function(object, bws) {
  if(class(object)!='rd') stop('object is not a rd object.')
  
  sim_results = lapply(bws, function(bw) {
    object$call$bw = bw
    object$call$est.cov = F
    new_model = eval.parent(object$call, 3)
     
    return(
      data.frame(
        est = new_model$est['Usr'], 
        se = new_model$se[4], 
        bw = bw, 
        model = c('usr'), 
        stringsAsFactors = F)
    )
  })
  
  return(
    do.call(rbind.data.frame, sim_results)
  )
}