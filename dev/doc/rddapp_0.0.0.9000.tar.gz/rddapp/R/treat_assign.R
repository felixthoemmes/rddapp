#' Treatment assignment for regression-discontinuity design (RDD)
#' 
#' \code{treat_assign} computes the treatment variable T 
#' based on the cutoff of assignment variables X
#' @param x Vector of assignment variable X 
#' @param cut Cutoff of assignment variables X
#' @param t.design Treatment option according to design.
#' The entry is for X: \code{'g'} means treatment is assigned 
#' if X is greater than its cutoff, \code{'geq'} means treatment is assigned 
#' if X is greater than or equal to its cutoff, \code{'l'} means treatment is assigned 
#' if X is less than its cutoff, \code{'leq'} means treatment is assigned 
#' if X is less than or equal to its cutoff.
#' @author Wang Liao
#' Ze Jin <\email{zj58@@cornell.edu}> 

treat_assign <- function(x, cut = 0, t.design = 'l') {
  if(t.design == 'geq')
    return(as.integer(x >= cut))
  if(t.design == 'g')
    return(as.integer(x > cut))
  if(t.design == 'leq')
    return(as.integer(x <= cut))
  if(t.design == 'l')
    return(as.integer(x < cut))
  stop("treatment design must be one of 'g', 'geq', 'l', 'leq'.")
}


