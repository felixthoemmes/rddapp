# Module UI
input_powerUI = function(id){
  ns = NS(id)
  tagList(
    
    ## FIRST BLOCK: ASSIGNMENT
    div(class='panel panel-default',
      div(class='panel-heading clearfix',
        h5(class='panel-title pull-left','Assignment'),
        actionButton(ns('allow_frontier'), label = NULL, 
          icon = icon('plus-square'), class='btn-sm pull-right',
          `data-toggle`="button", `aria-pressed`="false", autocomplete="off",
          title = 'allow a secondary assignment')
      ),
      div(class='panel-body',
        plotOutput(ns('assign_dist'), height = '125px'),
        
        h6(class='badge','Distribution'),
        
        div(class='input-group clearfix', style='margin-bottom:0;',
          div(class='input-group pull-left', 
            span(class='input-group-addon', 'A1'),
            span(class='input-group-btn',  actionButton(ns('assign1_dist'), label = 'normal',
              style = 'border-radius: 0'))
            
          ),
          div(class='input-group', style='margin-bottom:0;',
            conditionalPanel(condition = sprintf("input['%s'] %% 2 == 0", ns('assign1_dist')),class='input-group',
              span(class='input-group-addon', HTML('&mu;'), style='border-radius:0; border-left:0;'),
              numericInput(ns('assign1_mu'), label = NULL, value = 0, step = .1, width = '100%'),
              span(class='input-group-addon', HTML('&sigma;'), style='border-left:0;border-right:0;'),
              numericInput(ns('assign1_sigma'), label = NULL, value = 0, step = .1,min=1e-10,  width = '100%'),
              span(class='input-group-addon tail')
            ),
            conditionalPanel(condition = sprintf("input['%s'] %% 2 == 1", ns('assign1_dist')),class='input-group',
              span(class='input-group-addon','min', style='border-radius:0; border-left:0;'),
              numericInput(ns('assign1_min'), label = NULL, value = 0, step = .1, width = '100%'),
              span(class='input-group-addon','max', style='border-left:0;border-right:0;'),
              numericInput(ns('assign1_max'), label = NULL, value = 0, step = .1,  width = '100%'),
              span(class='input-group-addon tail')
            )
          )
          
        ),
        
        conditionalPanel(condition = sprintf("input['%s'] %% 2 == 1", ns('allow_frontier')),
          div(class='input-group clearfix',
            div(class='input-group pull-left', 
              span(class='input-group-addon', 'A2'),
              span(class='input-group-btn',  actionButton(ns('assign2_dist'), label = 'normal',
                style = 'border-radius: 0'))
              
            ),
            div(class='input-group',
              conditionalPanel(condition = sprintf("input['%s'] %% 2 == 0", ns('assign2_dist')),class='input-group',
                span(class='input-group-addon', HTML('&mu;'), style='border-radius:0; border-left:0;'),
                numericInput(ns('assign2_mu'), label = NULL, value = 0, step = .1, width = '100%'),
                span(class='input-group-addon', HTML('&sigma;'), style='border-left:0;border-right:0;'),
                numericInput(ns('assign2_sigma'), label = NULL, value = 0, step = .1, min = 1e-10, width = '100%'),
                span(class='input-group-addon tail')
              ),
              conditionalPanel(condition = sprintf("input['%s'] %% 2 == 1", ns('assign2_dist')),class='input-group',
                span(class='input-group-addon','min', style='border-radius:0; border-left:0;'),
                numericInput(ns('assign2_min'), label = NULL, value = 0, step = .1, width = '100%'),
                span(class='input-group-addon','max', style='border-left:0;border-right:0;'),
                numericInput(ns('assign2_max'), label = NULL, value = 0, step = .1, width = '100%'),
                span(class='input-group-addon tail')
              )
            )
          )
        ),
        
        h6(class='badge','Treatment Design'),
        
        div(class='input-group', 
          span(class='input-group-addon', 'A1'),
          span(class='input-group-btn', actionButton(ns('operator1'), label = '>',style='border-radius:0; border-right:0;')),
          numericInput(ns('assign1_cut'), label = NULL, value = 0, step = .1, min = 0, max = 1,width = '100%'),
          span(class='input-group-addon', 'with fuzziness', style='border-left:0;border-right:0;'),
          numericInput(ns('assign1_p1'), label = NULL, value = 0, step = .1, min = 0, max = 1,width = '100%'),
          span(class='input-group-addon tail', style='border-left:0;border-right:0;padding:0'),
          numericInput(ns('assign1_p2'), label = NULL, value = 0, step = .1, min = 0, max = 1,width = '100%'),
          span(class='input-group-addon tail')
          
        ),
        
        conditionalPanel(condition = sprintf("input['%s'] %% 2 == 1", ns('allow_frontier')),
          div(class='input-group', 
            span(class='input-group-addon', 'A2'),
            span(class='input-group-btn', actionButton(ns('operator2'), label = '>',style='border-radius:0; border-right:0;')),
            numericInput(ns('assign2_cut'), label = NULL, value = 0, step = .1, min = 0, max = 1,width = '100%'),
            span(class='input-group-addon', 'with fuzziness', style='border-left:0;border-right:0;'),
            numericInput(ns('assign2_p1'), label = NULL, value = 0, step = .1,min = 0, max = 1, width = '100%'),
            span(class='input-group-addon tail', style='border-left:0;border-right:0;padding:0'),
            numericInput(ns('assign2_p2'), label = NULL, value = 0, step = .1, min = 0, max = 1, width = '100%'),
            span(class='input-group-addon tail')
            
          )
          
        )
        
      )
    ),
    
    
    ## SECOND BLOCK
    div(class='panel panel-default', 
      
      div(class='panel-heading',
        h5('Parametric Model for Outcome')
      ),
      div(class='panel-body', 
        plotOutput(ns('par_model'), height = '325px')
      ),
      div(class='panel-footer',
        fluidRow(
          column(4, h6('Treatment'), style='padding-right:0px;',
            numericInput(ns('par_model_treatment'), label = NULL, value = 1, step = .05)),
          column(8, align = 'right', h6('Partial','η',tags$sup('2')), 
            sliderInput(
              ns('par_model_eta2'), 
              label = NULL, min = .01, max = .99, value = .5, step = .01, ticks = F)
          ),
          column(4, h6('Constant'), style='padding-right:0px;',
            numericInput(ns('par_model_constant'), label = NULL, value = 1, step = .05)),
          column(4, h6('Slope'), style='padding-right:3px;',
            numericInput(ns('par_model_slope'), label = NULL, value = .5, step = .05)),
          column(4, h6('Interaction'), style='padding-left:0px;',
            numericInput(ns('par_model_interact'), label = NULL, value = .25, step = .05))
        )
      )
      
    )
    
  )
}

# Module Server

input_power = function(input, output, session){
  
  observe({
    choice = input$operator1 %% 4 + 1
    updateActionButton(session, 'operator1', 
      label = c('\u2265','>','\u2264','<')[choice]
    )
  })
  
  observe({
    choice = input$operator2 %% 4 + 1
    updateActionButton(session, 'operator2', 
      label = c('\u2265','>','\u2264','<')[choice]
    )
  })  
  
  observe({
    choice = input$assign1_dist %% 2 + 1
    updateActionButton(session, 'assign1_dist', 
      label = c('normal','uniform')[choice]
    )
  })  
  
  observe({
    choice = input$assign2_dist %% 2 + 1
    updateActionButton(session, 'assign2_dist', 
      label = c('normal','uniform')[choice]
    )
  })  
    
  return()
  n = 50
  
  Var_noise = reactive({
    x.dist = input$assign_dist
    x.para = switch(input$assign_dist,
      'normal' = c(input$assign_mu, input$assign_sigma),
      'uniform' = c(input$assign_min, input$assign_max)
    )
    fuzzy.prob = c(input$assign_p1, input$assign_p2)
    cut =  input$assign_cut
    coef = c(input$par_model_constant, input$par_model_treatment,input$par_model_slope, input$par_model_interact)
    eta.sq = input$par_model_eta2
    
    if (x.dist == 'normal') {
      E_X <- x.para[1]
      Var_X <- x.para[2]^2
      
      E_T <- (1 - fuzzy.prob[1]) * pnorm(cut, mean = x.para[1], sd = x.para[2], lower.tail = FALSE) + 
        fuzzy.prob[2] * pnorm(cut, mean = x.para[1], sd = x.para[2], lower.tail = TRUE)
      
      
    } else if (x.dist == 'uniform') {
      E_X <- (x.para[1] + x.para[2]) / 2
      Var_X <- (x.para[1] - x.para[2])^2 / 12
      E_T <- (1 - fuzzy.prob[1]) * (x.para[2] - cut) / (x.para[2] - x.para[1]) + 
        fuzzy.prob[2] * (cut - x.para[1]) / (x.para[2] - x.para[1])
      
      
    } else {
      stop("distribution of assignment variable is not valid")
    }
    Var_T <- E_T - E_T^2
    Var_noise <- Var_T * (1 / eta.sq - 1)
    
    return(Var_noise)
  })
  
  # RENDER SLIDER FOR ETA2
  # output$par_model_eta2_slider = renderUI({
  #   ns = session$ns
  #   eta2_max = floor(vars()$Var_T / vars()$Var_Y * 1000) / 1000
  #   eta2_value = if(is.null(isolate(input$par_model_eta2))) signif(eta2_max /2, 3) else isolate(input$par_model_eta2) 
  #   sliderInput(
  #     ns('par_model_eta2'), 
  #     label = NULL, min = .001, max = eta2_max, value = eta2_value, step = .001)
  # })
  # 
  sample_norm = reactive({
    data.frame(X = rnorm(n, input$assign_mu, input$assign_sigma))
  })
  
  sample_uniform = reactive({
    data.frame(X =  runif(n, min = input$assign_min, max = input$assign_max))
  })
  
  sample_fuzzy = reactive({
    req(sample_uniform(), sample_norm())
    within(switch(input$assign_dist, 
      normal = sample_norm(),
      uniform = sample_uniform()),{
        Z = ifelse(X >= input$assign_cut, rbinom(n, 1, 1-input$assign_p2), 1-rbinom(n, 1, 1-input$assign_p1))
        
      })
  })
  input = list()
  input$assign1_sigma = 1
  input$assign1_mu = 0
  input$assign1_min = -1
  input$assign1_max = 1
  input$assign1_cut = .5
  input$assign1_dist = 'normal'
  input$allow_frontier = F
  
  parameter = list()
  parameter$operator1 = 'g'
  parameter$operator2 = 'g'
  
  output$assign_dist = renderPlot(bg = 'transparent', expr={
    par(mar = c(3,0,0.5,0))
    
    a1_norm = data.frame(x = seq(min(-3*input$assign1_sigma+input$assign1_mu, input$assign1_cut), 
            max(3 * input$assign1_sigma +input$assign1_mu, input$assign1_cut), length.out = 50))
    a1_norm$y = dnorm(a1_norm$x, mean = input$assign1_mu, sd = input$assign1_sigma)  
      
    a1_unif = data.frame(x = seq(min(input$assign1_min,input$assign1_cut), 
      max(input$assign1_max,input$assign1_cut), length.out = 50))
    
    a1_unif$y = dunif(a1_unif$x, min = input$assign1_min, max = input$assign1_max) 
    
    a2_norm = data.frame(x = seq(min(-3*input$assign2_sigma+input$assign2_mu, input$assign2_cut), 
            max(3 * input$assign2_sigma +input$assign2_mu, input$assign2_cut), length.out = 50))
    a2_norm$y = dnorm(a2_norm$x, mean = input$assign2_mu, sd = input$assign2_sigma)  
      
    a2_unif = data.frame(x = seq(min(input$assign2_min,input$assign2_cut), 
      max(input$assign2_max,input$assign2_cut), length.out = 50))
    
    a2_unif$y = dunif(a2_unif$x, min = input$assign2_min, max = input$assign2_max) 
    
    MASS::mvrnorm()
    
    fun1 = a1_norm
    fun1_tr = fun1[as.logical(get_tstar(fun1$x, input$assign1_cut, parameter$operator1)),]
    fun1_tr_poly = rbind(c(x = min(fun1_tr$x), y=0), fun1_tr, c(x = max(fun1_tr$x), y = 0))
    
    fun2 = a2_norm
    fun2_tr = fun2[as.logical(get_tstar(fun2$x, input$assign2_cut, parameter$operator2)),]
    fun2_tr_poly = rbind(c(x = min(fun2_tr$x), y=0), fun2_tr, c(x = max(fun2_tr$x), y = 0))
    
    
    layMat <- matrix(c(2,0,1,3), ncol=2, byrow=TRUE)
    layout(layMat, widths=c(6/7, 1/7), heights=c(1/7, 6/7))
    ospc <- 0 # outer space
    pext <- 2 # par extension down and to the left
    bspc <- 0 # space between scatter plot and bar plots
    par. <- par(mar=c(pext, pext, bspc, bspc),
                oma=rep(ospc, 4)) # plot parameters

    # center
    plot.new()
    plot.window(xlim=range(fun1$x), ylim=range(fun2$x))
    box()
    axis(1)
    axis(2)
    abline(v = input$assign1_cut, lty=3)
    abline(h = input$assign2_cut, lty=3)
    
    # top
    par(mar=c(0,pext,0,bspc))
    plot(fun1, type = 'l', bty = 'n', axes = 'n')
    abline(v = input$assign1_cut, lty=3)
    polygon(fun1_tr_poly, border = NA, col = adjustcolor('#428bca', alpha.f = .2))
    # right
    par(mar=c(pext,0,bspc,0))
    plot(x~y, fun2, type = 'l', bty= 'n', axes = 'n')
    abline(h = input$assign2_cut, lty=3)
    polygon(fun2_tr_poly$y, fun2_tr_poly$x, border = NA, col = adjustcolor('#428bca', alpha.f = .2))
    # # 3D
    # ele_3d = persp(z=matrix(rep(0,4),2,2), x = range(fun1$x), y = range(fun2$x),
    #   zlim = c(0, max(fun1$y, fun2$y)), expand = max(fun1$y, fun2$y), 
    #   d = 1, phi = 30, theta = 30,
    #   xlab = 'A1', ylab = 'A2', zlab = NA,
    #   ticktype = 'simple', box = F, 
    #   border = NULL, col=NA)
    # 
    # # fun1  
    # lines(trans3d(fun1$x, (max(fun2$x) + min(fun2$x))/2,fun1$y, pmat = ele_3d), 
    #   type = 'l', bty='n', yaxt ='n', ylab = NA, xlab = NA)
    # 
    # 
    # polygon(trans3d(fun1_tr_poly$x, (max(fun2$x) + min(fun2$x))/2,fun1_tr_poly$y, pmat = ele_3d), 
    #   border = NA, col = adjustcolor('#428bca', alpha.f = .2))
    # 
    # 
    # # fun2 
    # lines(trans3d((max(fun1$x) + min(fun1$x))/2, fun2$x, fun2$y, pmat = ele_3d), 
    #   type = 'l', bty='n', yaxt ='n', ylab = NA, xlab = NA)
    # 
    # polygon(trans3d( (max(fun1$x) + min(fun1$x))/2,fun2_tr_poly$x,fun2_tr_poly$y, pmat = ele_3d), 
    #   border = NA, col = adjustcolor('#428bca', alpha.f = .2))
    # 
    
    
    
    # abline(v = input$assign_cut, col = 'black', lty=3)
    
    req(sample_fuzzy())
    
    rug(sample_fuzzy()$X[sample_fuzzy()$Z==1], col = 'black', ticksize = .1)
    rug(sample_fuzzy()$X[sample_fuzzy()$Z==0], col = 'black', ticksize = -.1)
    
    y_max = max(hist(sample_fuzzy()$X, plot = F)$density) 
    text(x = input$assign_cut, y = max(fun$y) - strheight('T')*switch(input$assign_dist, normal = 5, uniform = 2), label = c('Treated'), pos = 4, cex = 1.1)
    text(x = input$assign_cut, y = max(fun$y) - strheight('T')*switch(input$assign_dist, normal = 5, uniform = 2), label = c('Untreated'), pos = 2, cex = 1.1)
    
  })
  
  # PLOT MODEL
  output$par_model = renderPlot(bg = 'transparent', expr = {
    req(sample_fuzzy())
    
    model = function(x, z) {
      x = x - input$assign_cut
      if(missing(z))
        z = as.integer(x >= 0)
      y = ifelse(x!=0, input$par_model_constant + input$par_model_treatment * z + input$par_model_slope * x + input$par_model_interact * z * x,  NA)
      return(y)
    }
    
    
    df = within(sample_fuzzy(), {
      # y_out <- y_out + rnorm(sample.size, 0, sqrt(Var_noise))
      Y_hat = model(X, Z) + rnorm(n, 0, sqrt(Var_noise()))
      
    })
    
    par(mar = c(3,0,0,0))
    plot.new()
    plot.window(xlim = switch(input$assign_dist,
      'normal' = range(c(3,-3)*input$assign_sigma+input$assign_mu, input$assign_cut, df$X),
      'uniform' = range(min(input$assign_min,input$assign_cut) - .1, max(input$assign_max,input$assign_cut)+.1)
    ),
      ylim = range(df$Y_hat, df$Y))
    
    curve(model,
      from = switch(input$assign_dist,
        'normal' = min(-3*input$assign_sigma+input$assign_mu, input$assign_cut),
        'uniform' = min(input$assign_min,input$assign_cut) - .1
      ), 
      to= input$assign_cut,  add= T,
      col = 'black', lwd = 2)
    curve(model,
      from = input$assign_cut, 
      to= switch(input$assign_dist,
        'normal' = max(3*input$assign_sigma+input$assign_mu, input$assign_cut),
        'uniform' = max(input$assign_max,input$assign_cut) + .1
      ), add= T,
      col = 'black', lwd = 2)
    
    
    axis(4, lwd = 0, lwd.ticks = 1, pos = input$assign_cut , at = c(input$par_model_constant, input$par_model_treatment + input$par_model_constant),
      labels = c(input$par_model_constant, NA))
    axis(2, pos = input$assign_cut , at = c(input$par_model_constant, input$par_model_treatment + input$par_model_constant),
      labels = c(NA, input$par_model_treatment + input$par_model_constant))
    axis(1)
    abline(v= input$assign_cut, col = 'black', lty=3)
    # segments(df$X[df$Z==0], df$Y_hat[df$Z==0], y1 = df$Y[df$Z==0], col = 'darkgray')
    # segments(df$X[df$Z==1], df$Y_hat[df$Z==1], y1 = df$Y[df$Z==1], col = 'black')
    mtext('Assignment', 1, 2)
    mtext('Outcome',2, 2, at = input$assign_cut)
    legend(x = 'bottomright', bty = 'n', legend = c('treated','untreated'), pch = c(19,1))
    
    # empirical points
    points(Y_hat ~ X, data = df[df$Z==0,], col = 'black', pch = 1)
    points(Y_hat ~ X, data = df[df$Z==1,], col = 'black', pch = 19)
    
    
    
    # empirical ci
    # level = .95
    # pred_ci = within(
    #   data.frame(x = switch(input$assign_dist,
    #     'normal' = seq(min(-3*input$assign_sigma+input$assign_mu, input$assign_cut),
    #       max(3*input$assign_sigma+input$assign_mu, input$assign_cut),
    #       length.out = 60),
    #     'uniform' = seq(min(input$assign_min,input$assign_cut) - .1,
    #       max(input$assign_max,input$assign_cut) + .1,
    #       length.out = 60))),
    #   expr = {
    #     n_hat = c(n*diff(switch(input$assign_dist,
    #       normal = pnorm(x, mean = input$assign_mu, sd = input$assign_sigma),
    #       uniform = punif(x, min = input$assign_min, max = input$assign_max))
    #     ), NA)
    #     y_ub = model(x) + qt((1-level)/2 , df = n_hat - 1) * sqrt(Var_noise())
    #     y_lb = model(x) - qt((1-level)/2 , df = n_hat - 1) * sqrt(Var_noise())
    #       })
    # print(pred_ci)
    # lines(y_ub ~ x, pred_ci)
    # lines(y_lb ~ x, pred_ci)
    
  })
  
  power_pars  = reactive({
    
    pars=list(
      x_dist = input$assign_dist,
      x_para = switch(input$assign_dist, 
        'normal' = c(input$assign_mu, input$assign_sigma),
        'uniform' = c(input$assign_min, input$assign_max)
      ),
      # x_n = n,
      x_p = c(1-input$assign_p1, 1-input$assign_p2),
      x_c = input$assign_cut,
      m_coef = c(input$par_model_constant, input$par_model_treatment,input$par_model_slope, input$par_model_interact),
      m_eta2 = input$par_model_eta2
    )
    
    return(pars)
  })
  return(power_pars)
}


